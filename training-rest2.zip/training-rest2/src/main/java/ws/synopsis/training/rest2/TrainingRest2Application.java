package ws.synopsis.training.rest2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingRest2Application {

	public static void main(String[] args) {
		SpringApplication.run(TrainingRest2Application.class, args);
	}

}
